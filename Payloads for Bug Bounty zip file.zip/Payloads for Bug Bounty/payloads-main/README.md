this payload list contains all payloads used in bug hunting..some are my personal and some are from public..i hope this will help you in bug hunting jurney..

⚠️ **Disclaimer**: The content in this repository is for educational and informational purposes only; the authors hold no responsibility for misuse. Ensure proper authorization before use, act responsibly at your own risk, and comply with all legal and ethical guidelines. 🚀
